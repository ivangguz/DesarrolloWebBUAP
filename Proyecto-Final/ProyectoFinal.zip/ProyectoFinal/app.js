const express = require('express');
const dotenv = require('dotenv');
const db = require('./src/config/db'); // Assuming you're using this for DB connection
const homeRoutes = require('./src/routes/indexRoute'); // Import the home routes


dotenv.config();

const app = express();

// Middleware
app.use(express.json());
app.use(express.static('public'));

// Set EJS as the view engine
app.set('view engine', 'ejs'); // This tells Express to use EJS for rendering views

// Use routes from homeRoutes.js
app.use('/', homeRoutes); // Mount homeRoutes on the root path

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
